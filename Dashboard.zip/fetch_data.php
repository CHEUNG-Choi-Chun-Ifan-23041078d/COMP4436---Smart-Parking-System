<?php
require_once 'config.php';

// Connect to MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Function to fetch latest distance from ThingSpeak
function getThingSpeakDistance($field)
{
    $url = "https://api.thingspeak.com/channels/" . THINGSPEAK_CHANNEL_ID . "/fields/$field/last.json?api_key=" . THINGSPEAK_READ_API_KEY;
    $response = file_get_contents($url);
    if ($response === false) {
        return null;
    }
    $data = json_decode($response, true);
    return isset($data["field$field"]) ? floatval($data["field$field"]) : null;
}

// Fetch statuses for all slots
$statuses = [];
foreach ($parking_slots as $slot_id => $slot) {
    $thingspeak_field = isset($slot['thingspeak_field']) ? $slot['thingspeak_field'] : null;
    if ($thingspeak_field !== null) {
        $distance = getThingSpeakDistance($thingspeak_field);
        if ($distance === null) {
            $statuses[$slot_id] = ['status' => 'Unknown', 'distance' => 0, 'car_plate' => null];
            $sql = "SELECT `status`, `car_plate` FROM `parking_logs` WHERE `slot_id` = ? ORDER BY `timestamp` DESC LIMIT 1";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $slot_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $last = $result->num_rows > 0 ? $result->fetch_assoc() : ['status' => null, 'car_plate' => null];
            $stmt->close();
            if ($last['status'] !== 'Unknown') {
                $sql = "INSERT INTO `parking_logs` (`slot_id`, `timestamp`, `status`, `distance`, `car_plate`) VALUES (?, NOW(), ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('ssds', $slot_id, 'Unknown', 0.0, null);
                $stmt->execute();
                $stmt->close();
            }
            continue;
        }
        $status = ($distance > 0 && $distance < 400) ? ($distance < 10 ? 'Using' : 'Free') : 'Free';
        $sql = "SELECT `status`, `car_plate` FROM `parking_logs` WHERE `slot_id` = ? ORDER BY `timestamp` DESC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $slot_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $last = $result->num_rows > 0 ? $result->fetch_assoc() : ['status' => null, 'car_plate' => null];
        $stmt->close();
        if ($last['status'] !== $status) {
            $sql = "INSERT INTO `parking_logs` (`slot_id`, `timestamp`, `status`, `distance`, `car_plate`) VALUES (?, NOW(), ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ssds', $slot_id, $status, $distance, $last['car_plate']);
            $stmt->execute();
            $stmt->close();
        }
        $statuses[$slot_id] = ['status' => $status, 'distance' => $distance, 'car_plate' => $last['car_plate']];
    } else {
        $sql = "SELECT `status`, `distance`, `car_plate` FROM `parking_logs` WHERE `slot_id` = ? ORDER BY `timestamp` DESC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $slot_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $statuses[$slot_id] = $result->num_rows > 0 ? $result->fetch_assoc() : ['status' => 'Free', 'distance' => 0, 'car_plate' => null];
        $stmt->close();
    }
}

header('Content-Type: application/json');
echo json_encode($statuses);

$conn->close();