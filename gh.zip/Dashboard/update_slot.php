<?php
ob_start();
header('Content-Type: application/json');
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

require_once 'config.php';

error_log("update_slot.php: Script started");

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    error_log("update_slot.php: Database connection failed: " . $conn->connect_error);
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    ob_end_flush();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("update_slot.php: Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    ob_end_flush();
    exit;
}

$slot_id = $_POST['slot_id'] ?? '';
$status = $_POST['status'] ?? '';
$car_plate = $_POST['car_plate'] ?? null;

error_log("update_slot.php: Input - slot_id: $slot_id, status: $status, car_plate: " . ($car_plate ?? 'null'));

if (!array_key_exists($slot_id, $parking_slots)) {
    error_log("update_slot.php: Invalid slot_id: $slot_id");
    http_response_code(400);
    echo json_encode(['error' => 'Invalid slot ID']);
    ob_end_flush();
    exit;
}

if (!in_array($status, ['Free', 'Using', 'Unknown', 'RESERVED'])) {
    error_log("update_slot.php: Invalid status: $status");
    http_response_code(400);
    echo json_encode(['error' => 'Invalid status']);
    ob_end_flush();
    exit;
}

if (($status === 'Using' || $status === 'RESERVED') && empty($car_plate)) {
    error_log("update_slot.php: Car plate required for $status status");
    http_response_code(400);
    echo json_encode(['error' => "Car plate is required when status is $status"]);
    ob_end_flush();
    exit;
}

if ($status === 'Free' || $status === 'Unknown') {
    $car_plate = null;
} else {
    $car_plate = filter_var($car_plate, FILTER_SANITIZE_STRING);
}

error_log("update_slot.php: Sanitized car_plate: " . ($car_plate ?? 'null'));

$sql = "INSERT INTO parking_status (space_id, status, car_plate) VALUES (?, ?, ?) 
        ON DUPLICATE KEY UPDATE status = ?, car_plate = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("update_slot.php: Prepare failed for parking_status: " . $conn->error);
    http_response_code(500);
    echo json_encode(['error' => 'Database query preparation failed']);
    $conn->close();
    ob_end_flush();
    exit;
}
$stmt->bind_param('sssss', $slot_id, $status, $car_plate, $status, $car_plate);
if (!$stmt->execute()) {
    error_log("update_slot.php: Execute failed for parking_status: " . $stmt->error);
    http_response_code(500);
    echo json_encode(['error' => 'Failed to update parking_status']);
    $stmt->close();
    $conn->close();
    ob_end_flush();
    exit;
}
$stmt->close();

error_log("update_slot.php: parking_status updated for slot_id: $slot_id");

$sql = "SELECT `status` FROM `parking_logs` WHERE `slot_id` = ? ORDER BY `timestamp` DESC LIMIT 1";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("update_slot.php: Prepare failed for parking_logs: " . $conn->error);
    http_response_code(500);
    echo json_encode(['error' => 'Database query preparation failed']);
    $conn->close();
    ob_end_flush();
    exit;
}
$stmt->bind_param('s', $slot_id);
if (!$stmt->execute()) {
    error_log("update_slot.php: Execute failed for parking_logs: " . $stmt->error);
    http_response_code(500);
    echo json_encode(['error' => 'Failed to query parking_logs']);
    $stmt->close();
    $conn->close();
    ob_end_flush();
    exit;
}
$result = $stmt->get_result();
$last_status = $result->num_rows > 0 ? $result->fetch_assoc()['status'] : null;
$stmt->close();

error_log("update_slot.php: Last status for slot_id $slot_id: " . ($last_status ?? 'none'));

if ($last_status !== $status) {
    $distance = ($status === 'Using' || $status === 'RESERVED') ? 5.00 : ($status === 'Free' ? 50.00 : 0.00);
    $sql = "INSERT INTO `parking_logs` (`slot_id`, `timestamp`, `status`, `distance`, `car_plate`) VALUES (?, NOW(), ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("update_slot.php: Prepare failed for parking_logs insert: " . $conn->error);
        http_response_code(500);
        echo json_encode(['error' => 'Database query preparation failed']);
        $conn->close();
        ob_end_flush();
        exit;
    }
    $stmt->bind_param('ssds', $slot_id, $status, $distance, $car_plate);
    if (!$stmt->execute()) {
        error_log("update_slot.php: Execute failed for parking_logs insert: " . $stmt->error);
        http_response_code(500);
        echo json_encode(['error' => 'Failed to log update to database']);
        $stmt->close();
        $conn->close();
        ob_end_flush();
        exit;
    }
    $stmt->close();

    error_log("update_slot.php: parking_logs inserted for slot_id: $slot_id, status: $status");
}

echo json_encode(['success' => true]);

error_log("update_slot.php: Script completed");

$conn->close();
ob_end_flush();
