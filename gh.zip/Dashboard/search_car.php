<?php
ob_start();
header('Content-Type: application/json');
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

require_once 'config.php';
error_log("search_car.php: Script started");

// Connect to MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    error_log("search_car.php: Database connection failed: " . $conn->connect_error);
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    ob_end_flush();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    error_log("search_car.php: Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    ob_end_flush();
    exit;
}

$car_plate = $_GET['car_plate'] ?? '';
if (empty($car_plate)) {
    error_log("search_car.php: Car plate missing");
    http_response_code(400);
    echo json_encode(['error' => 'Car plate is required']);
    ob_end_flush();
    exit;
}

$car_plate = filter_var($car_plate, FILTER_SANITIZE_STRING);

error_log("search_car.php: Searching for car plate: $car_plate");

$current = null;
$sql = "SELECT `slot_id`, `status`, `distance`, `car_plate` FROM `parking_logs` WHERE `car_plate` = ? AND `status` = 'Using' ORDER BY `timestamp` DESC LIMIT 1";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("search_car.php: Prepare failed: " . $conn->error);
    http_response_code(500);
    echo json_encode(['error' => 'Database query preparation failed']);
    $conn->close();
    ob_end_flush();
    exit;
}
$stmt->bind_param('s', $car_plate);
if (!$stmt->execute()) {
    error_log("search_car.php: Execute failed: " . $stmt->error);
    http_response_code(500);
    echo json_encode(['error' => 'Database query execution failed']);
    $stmt->close();
    $conn->close();
    ob_end_flush();
    exit;
}
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $current = $row;
}
$stmt->close();

error_log("search_car.php: Current parking found: " . ($current ? json_encode($current) : "None"));

$history = [];
$sql = "SELECT `slot_id`, `timestamp`, `status`, `distance`, `car_plate` FROM `parking_logs` WHERE `car_plate` = ? ORDER BY `timestamp` DESC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("search_car.php: Prepare failed: " . $conn->error);
    http_response_code(500);
    echo json_encode(['error' => 'Database query preparation failed']);
    $conn->close();
    ob_end_flush();
    exit;
}
$stmt->bind_param('s', $car_plate);
if (!$stmt->execute()) {
    error_log("search_car.php: Execute failed: " . $stmt->error);
    http_response_code(500);
    echo json_encode(['error' => 'Database query execution failed']);
    $stmt->close();
    $conn->close();
    ob_end_flush();
    exit;
}
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $history[] = $row;
}
$stmt->close();

error_log("search_car.php: History entries found: " . count($history));

echo json_encode(['current' => $current, 'history' => $history]);

error_log("search_car.php: Script completed");

$conn->close();
ob_end_flush();