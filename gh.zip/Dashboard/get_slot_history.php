<?php
require_once 'config.php';

// Connect to MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$slot_id = $_GET['slot_id'] ?? '';
if (!array_key_exists($slot_id, $parking_slots)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid slot ID']);
    exit;
}

// Fetch history (last 20 records)
$sql = "SELECT `timestamp`, `status`, `distance`, `car_plate` FROM `parking_logs` WHERE `slot_id` = ? ORDER BY `timestamp` DESC LIMIT 20";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $slot_id);
$stmt->execute();
$result = $stmt->get_result();

$history = [];
while ($row = $result->fetch_assoc()) {
    $history[] = $row;
}

header('Content-Type: application/json');
echo json_encode($history);

$stmt->close();
$conn->close();