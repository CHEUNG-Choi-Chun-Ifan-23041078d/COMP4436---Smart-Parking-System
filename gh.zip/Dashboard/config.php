<?php
// DB configuration
define('DB_HOST', 'sdb-85.hosting.stackcp.net');
define('DB_USER', 'comp4436-353039389f0e');
define('DB_PASS', 'r41bitei3p');
define('DB_NAME', 'comp4436-353039389f0e');

// ThingSpeak configuration
define('THINGSPEAK_CHANNEL_ID', 2920365);
define('THINGSPEAK_READ_API_KEY', 'VC3UFJB1VOG1JKJN');

// Parking slots configuration
$parking_slots = [
    'P101' => ['type' => 'Disabled', 'thingspeak_field' => 1],
    'P102' => ['type' => 'EV', 'thingspeak_field' => 2],
    'P103' => ['type' => 'EV', 'thingspeak_field' => 3],
    'P104' => ['type' => 'EV', 'thingspeak_field' => null],
    'P105' => ['type' => 'Normal', 'thingspeak_field' => null],
    'P106' => ['type' => 'Normal', 'thingspeak_field' => null],
    'P107' => ['type' => 'Normal', 'thingspeak_field' => null],
    'P108' => ['type' => 'Normal', 'thingspeak_field' => null],
    'P109' => ['type' => 'Normal', 'thingspeak_field' => null],
    'P110' => ['type' => 'Normal', 'thingspeak_field' => null]
];

ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');
error_reporting(E_ALL);
