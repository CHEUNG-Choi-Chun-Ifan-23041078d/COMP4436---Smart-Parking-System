<?php
require_once 'config.php';

// Connect to MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch current status for all slots
$statuses = [];
foreach ($parking_slots as $slot_id => $slot) {
    $sql = "SELECT `status`, `distance`, `car_plate` FROM `parking_logs` WHERE `slot_id` = ? ORDER BY `timestamp` DESC LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $slot_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $statuses[$slot_id] = $row;
    } else {
        $statuses[$slot_id] = ['status' => 'Free', 'distance' => 0, 'car_plate' => null];
    }
    $stmt->close();
}

// Check parking privilege warnings
$ev_slots = array_filter($parking_slots, fn($slot) => $slot['type'] === 'EV');
$normal_slots = array_filter($parking_slots, fn($slot) => $slot['type'] === 'Normal');
$ev_occupied = count(array_filter($statuses, fn($s, $id) => $s['status'] === 'Using' && array_key_exists($id, $ev_slots), ARRAY_FILTER_USE_BOTH));
$normal_occupied = count(array_filter($statuses, fn($s, $id) => $s['status'] === 'Using' && array_key_exists($id, $normal_slots), ARRAY_FILTER_USE_BOTH));
$warnings = [];
foreach ($statuses as $slot_id => $status) {
    if ($status['status'] === 'Using' && $parking_slots[$slot_id]['type'] === 'EV' && $normal_occupied < count($normal_slots)) {
        $warnings[$slot_id] = "Normal car in EV slot while Normal slots are available";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Park Management Dashboard</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1><i class="fas fa-parking"></i> Car Park Management Dashboard</h1>
        <div class="search-bar">
            <input type="text" id="car-plate-search" placeholder="Search by car plate (e.g., EV123)">
            <button id="search-button"><i class="fas fa-search"></i> Search</button>
        </div>
        <div id="search-results" class="search-results"></div>
        <div class="parking-map">
            <?php foreach ($parking_slots as $slot_id => $slot): ?>
            <div class="parking-slot <?php echo strtolower($statuses[$slot_id]['status']); ?>"
                data-slot-id="<?php echo $slot_id; ?>">
                <div class="slot-content">
                    <h3><?php echo $slot_id; ?> (<?php echo $slot['type']; ?>)</h3>
                    <p>Status: <span class="slot-status"><?php echo $statuses[$slot_id]['status']; ?></span></p>
                    <p>Car Plate: <span
                            class="slot-plate"><?php echo htmlspecialchars($statuses[$slot_id]['car_plate'] ?: 'N/A'); ?></span>
                    </p>
                    <?php if (isset($warnings[$slot_id])): ?>
                    <p class="warning"><i class="fas fa-exclamation-triangle"></i> <?php echo $warnings[$slot_id]; ?>
                    </p>
                    <?php endif; ?>
                </div>
                <form class="update-form" data-slot-id="<?php echo $slot_id; ?>">
                    <div class="form-group">
                        <label for="status-<?php echo $slot_id; ?>">Status:</label>
                        <select id="status-<?php echo $slot_id; ?>" name="status" class="status-select">
                            <option value="Free"
                                <?php echo $statuses[$slot_id]['status'] === 'Free' ? 'selected' : ''; ?>>
                                Free</option>
                            <option value="Using"
                                <?php echo $statuses[$slot_id]['status'] === 'Using' ? 'selected' : ''; ?>>Using
                            </option>
                            <option value="Unknown"
                                <?php echo $statuses[$slot_id]['status'] === 'Unknown' ? 'selected' : ''; ?>>Unknown
                            </option>
                            <option value="RESERVED"
                                <?php echo $statuses[$slot_id]['status'] === 'RESERVED' ? 'selected' : ''; ?>>Reserved
                            </option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="car-plate-<?php echo $slot_id; ?>">Car Plate:</label>
                        <input type="text" id="car-plate-<?php echo $slot_id; ?>" name="car_plate"
                            value="<?php echo htmlspecialchars($statuses[$slot_id]['car_plate'] ?: ''); ?>"
                            placeholder="e.g., EV123" class="car-plate-input" maxlength="10"
                            pattern="[A-Za-z0-9-]{1,10}">
                    </div>
                    <button type="submit" class="update-button"><i class="fas fa-save"></i> Update</button>
                </form>
            </div>
            <?php endforeach; ?>
        </div>
        <div id="history-modal" class="modal">
            <div class="modal-content">
                <span class="close">×</span>
                <h2>Parking History for <span id="modal-slot-id"></span></h2>
                <table id="history-table">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>Slot</th>
                            <th>Status</th>
                            <th>Distance (cm)</th>
                            <th>Car Plate</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="js/script.js?v=<?php echo time(); ?>"></script>
</body>

</html>
<?php
$conn->close();
?>