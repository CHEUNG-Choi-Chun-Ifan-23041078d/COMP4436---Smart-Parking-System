document.addEventListener("DOMContentLoaded", () => {
  const modal = document.getElementById("history-modal");
  const modalSlotId = document.getElementById("modal-slot-id");
  const historyTableBody = document.querySelector("#history-table tbody");
  const closeModal = document.querySelector(".close");
  const searchInput = document.getElementById("car-plate-search");
  const searchButton = document.getElementById("search-button");
  const searchResults = document.getElementById("search-results");

  // Update dashboard
  function updateDashboard() {
    fetch("fetch_data.php")
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        Object.keys(data).forEach((slotId) => {
          const slotElement = document.querySelector(
            `.parking-slot[data-slot-id="${slotId}"]`
          );
          if (slotElement) {
            const statusElement = slotElement.querySelector(".slot-status");
            const plateElement = slotElement.querySelector(".slot-plate");
            const statusSelect = slotElement.querySelector(".status-select");
            const carPlateInput = slotElement.querySelector(".car-plate-input");
            statusElement.textContent = data[slotId].status;
            // Explicitly clear car plate for Free status
            plateElement.textContent =
              data[slotId].status === "Free"
                ? "N/A"
                : data[slotId].car_plate || "N/A";
            statusSelect.value = data[slotId].status;
            carPlateInput.value =
              data[slotId].status === "Free"
                ? ""
                : data[slotId].car_plate || "";
            carPlateInput.disabled = ["Free", "Unknown"].includes(
              data[slotId].status
            );
            // Ensure correct status class is applied
            slotElement.classList.remove(
              "using",
              "free",
              "unknown",
              "reserved"
            );
            slotElement.classList.add(data[slotId].status.toLowerCase());
          }
        });
      })
      .catch((error) => console.error("Fetch error:", error));
  }

  // Handle slot click to show history
  document.querySelectorAll(".parking-slot").forEach((slot) => {
    slot.addEventListener("click", (e) => {
      if (
        e.target.tagName === "BUTTON" ||
        e.target.tagName === "INPUT" ||
        e.target.tagName === "SELECT"
      ) {
        return; // Ignore clicks on form elements
      }
      const slotId = slot.dataset.slotId;
      modalSlotId.textContent = slotId;
      fetch(`get_slot_history.php?slot_id=${slotId}`)
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          return response.json();
        })
        .then((history) => {
          historyTableBody.innerHTML = "";
          history.forEach((log) => {
            const row = document.createElement("tr");
            row.innerHTML = `
              <td>${log.timestamp}</td>
              <td>${log.slot_id}</td>
              <td>${log.status}</td>
              <td>${log.distance.toFixed(2)}</td>
              <td>${log.car_plate || "N/A"}</td>
            `;
            historyTableBody.appendChild(row);
          });
          modal.style.display = "flex";
        })
        .catch((error) => console.error("History fetch error:", error));
    });
  });

  // Close modal
  closeModal.addEventListener("click", () => {
    modal.style.display = "none";
  });

  // Handle form submissions and car plate validation
  document.querySelectorAll(".update-form").forEach((form) => {
    const statusSelect = form.querySelector(".status-select");
    const carPlateInput = form.querySelector(".car-plate-input");

    // Toggle car plate input based on status
    function toggleCarPlateInput() {
      const isDisabled = ["Free", "Unknown"].includes(statusSelect.value);
      carPlateInput.disabled = isDisabled;
      carPlateInput.value = isDisabled ? "" : carPlateInput.value;
      carPlateInput.classList.remove("error");
    }

    statusSelect.addEventListener("change", toggleCarPlateInput);
    toggleCarPlateInput(); // Initialize state

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const slotId = form.dataset.slotId;
      const status = statusSelect.value;
      const carPlate = carPlateInput.value.trim();

      // Client-side validation
      if (
        (status === "Using" || status === "RESERVED") &&
        !carPlate.match(/^[A-Za-z0-9-]{1,10}$/)
      ) {
        carPlateInput.classList.add("error");
        alert("Please enter a valid car plate (1-10 alphanumeric characters).");
        return;
      }

      const formData = new FormData(form);
      formData.append("slot_id", slotId);
      fetch("update_slot.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => {
          if (!response.ok) {
            return response.text().then((text) => {
              console.error("Update response:", text);
              throw new Error(`HTTP error! status: ${response.status}`);
            });
          }
          return response.json();
        })
        .then((data) => {
          if (data.error) {
            alert("Error: " + data.error);
          } else {
            updateDashboard();
            alert("Slot updated successfully!");
            carPlateInput.classList.remove("error");
          }
        })
        .catch((error) => {
          console.error("Update error:", error);
          alert("Failed to update slot: " + error.message);
        });
    });
  });

  // Handle car plate search
  function performSearch() {
    const carPlate = searchInput.value.trim();
    if (!carPlate) {
      alert("Please enter a car plate.");
      return;
    }
    fetch(`search_car.php?car_plate=${encodeURIComponent(carPlate)}`)
      .then((response) => {
        if (!response.ok) {
          return response.text().then((text) => {
            console.error("Search response:", text);
            throw new Error(`HTTP error! status: ${response.status}`);
          });
        }
        return response.json();
      })
      .then((data) => {
        searchResults.innerHTML = "";
        if (data.error) {
          searchResults.innerHTML = `<p class="error">${data.error}</p>`;
        } else {
          let html = "";
          if (data.current) {
            html += `
              <h3>Current Parking</h3>
              <p>Slot: ${data.current.slot_id}</p>
              <p>Status: ${data.current.status}</p>
              <p>Distance: ${data.current.distance.toFixed(2)} cm</p>
              <p>Car Plate: ${data.current.car_plate}</p>
            `;
          } else {
            html += `<p>No car with plate "${carPlate}" is currently parked.</p>`;
          }
          if (data.history.length > 0) {
            html += `
              <h3>Parking History</h3>
              <table>
                <thead>
                  <tr>
                    <th>Timestamp</th>
                    <th>Slot</th>
                    <th>Status</th>
                    <th>Distance (cm)</th>
                    <th>Car Plate</th>
                  </tr>
                </thead>
                <tbody>
            `;
            data.history.forEach((log) => {
              html += `
                <tr>
                  <td>${log.timestamp}</td>
                  <td>${log.slot_id}</td>
                  <td>${log.status}</td>
                  <td>${log.distance.toFixed(2)}</td>
                  <td>${log.car_plate || "N/A"}</td>
                </tr>
              `;
            });
            html += "</tbody></table>";
          } else {
            html += `<p>No parking history found for "${carPlate}".</p>`;
          }
          searchResults.innerHTML = html;
          searchResults.classList.add("show");
        }
      })
      .catch((error) => {
        console.error("Search error:", error);
        searchResults.innerHTML =
          '<p class="error">Failed to fetch search results: ' +
          error.message +
          "</p>";
        searchResults.classList.add("show");
      });
  }

  searchButton.addEventListener("click", performSearch);
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      performSearch();
    }
  });

  // Initial update and periodic refresh
  updateDashboard();
  setInterval(updateDashboard, 15000);
});
